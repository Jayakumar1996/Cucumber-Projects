package stepdefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import baseclass.BaseClass;
import io.cucumber.java.en.When;

public class MyListing extends BaseClass {
	
	@When("User navigates to My Listing module")
	public void user_navigates_to_my_listing_module() {

		driver.findElement(By.xpath("//div[text()='My Listing']")).click();
	}

	@When("User clicks the required dropdown and then the results are displayed")
	public void user_clicks_the_required_dropdown_and_then_the_results_are_displayed() {

		WebElement dropdownField = driver.findElement(By.id("calender"));
		Select dropdown = new Select(dropdownField);
        dropdown.selectByVisibleText("Sold"); 
        
        // Get the currently selected option
        WebElement selectedOption = dropdown.getFirstSelectedOption();
        System.out.println("Selected option: " + selectedOption.getText());

        // Get all options from the dropdown
        List<WebElement> allOptions = dropdown.getOptions();
        System.out.println("All options:");
        for (WebElement option : allOptions) {
            System.out.println(option.getText());
        }

	}

}
